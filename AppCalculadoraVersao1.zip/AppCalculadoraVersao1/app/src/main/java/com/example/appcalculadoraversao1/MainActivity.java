package com.example.appcalculadoraversao1;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edv1, edv2, edresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edv1 = (EditText) findViewById(R.id.editTextValor1);
        edv2 = (EditText) findViewById(R.id.editTextValor2);
        edresult = (EditText) findViewById(R.id.editTextResultado);
    }

    public void somar(View v){
        Calculadora soma = new Calculadora();
        soma.setValor1(Double.parseDouble(edv1.getText().toString()));
        soma.setValor2(Double.parseDouble(edv2.getText().toString()));
        edresult.setText(String.format("%.3f",soma.Somar()));
    }

    public void subtrair(View v){
        Calculadora subtracao = new Calculadora();
        subtracao.setValor1(Double.parseDouble(edv1.getText().toString()));
        subtracao.setValor2(Double.parseDouble(edv2.getText().toString()));
        edresult.setText(String.format("%.3f",subtracao.Subtracao()));
    }

    public void multiplicar(View v){
        Calculadora multiplicar = new Calculadora();
        multiplicar.setValor1(Double.parseDouble(edv1.getText().toString()));
        multiplicar.setValor2(Double.parseDouble(edv2.getText().toString()));
        edresult.setText(String.format("%.3f",multiplicar.Multiplicacao()));
    }

    public void dividir(View v){
        Calculadora dividir = new Calculadora();
        dividir.setValor1(Double.parseDouble(edv1.getText().toString()));
        dividir.setValor2(Double.parseDouble(edv2.getText().toString()));
        edresult.setText(String.format("%.3f",dividir.Divisao()));
    }
}
