package com.example.appcalculadoraversao2;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edValor1, edValor2, edResultado;
    RadioButton rbSoma, rbSubtracao, rbMultiplicacao, rbDivisao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edValor1 = (EditText)findViewById(R.id.editTextValor1);
        edValor2 = (EditText)findViewById(R.id.editTextValor2);
        edResultado = (EditText)findViewById(R.id.editTextResultado);
        rbSoma = (RadioButton)findViewById(R.id.radioButtonSoma);
        rbSubtracao = (RadioButton)findViewById(R.id.radioButtonSubtracao);
        rbMultiplicacao = (RadioButton)findViewById(R.id.radioButtonMultiplicacao);
        rbDivisao = (RadioButton)findViewById(R.id.radioButtonDivisao);
    }

    public void calcular(View v){
        int opcao;
        if(rbSoma.isChecked()){
            Calculadora soma = new Calculadora();
            soma.setValor1(Double.parseDouble(edValor1.getText().toString()));
            soma.setValor2(Double.parseDouble(edValor2.getText().toString()));
            edResultado.setText(String.format("%.3f",soma.Somar()));
        }
        else if(rbSubtracao.isChecked()){
            Calculadora subtracao = new Calculadora();
            subtracao.setValor1(Double.parseDouble(edValor1.getText().toString()));
            subtracao.setValor2(Double.parseDouble(edValor2.getText().toString()));
            edResultado.setText(String.format("%.3f",subtracao.Subtracao()));

        }
        else if(rbMultiplicacao.isChecked()){
            Calculadora multiplicar = new Calculadora();
            multiplicar.setValor1(Double.parseDouble(edValor1.getText().toString()));
            multiplicar.setValor2(Double.parseDouble(edValor2.getText().toString()));
            edResultado.setText(String.format("%.3f",multiplicar.Multiplicacao()));

        }

        else if(rbDivisao.isChecked()){
            Calculadora dividir = new Calculadora();
            dividir.setValor1(Double.parseDouble(edValor1.getText().toString()));
            dividir.setValor2(Double.parseDouble(edValor2.getText().toString()));
            edResultado.setText(String.format("%.3f",dividir.Divisao()));
        }
    }
}
