package com.example.appcalculadoraversao3;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edv1, edv2, edresult;
    Spinner spinner1;
    int opcao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edv1 = (EditText) findViewById(R.id.editTextValor1);
        edv2 = (EditText) findViewById(R.id.editTextValor2);
        edresult = (EditText) findViewById(R.id.editTextResultado);
        spinner1 = (Spinner) findViewById(R.id.spinner);


    }

    public void calcular(View v){
        if(spinner1.getSelectedItem().toString().equals("Soma")){
            opcao = 1;
        }
        else if (spinner1.getSelectedItem().toString().equals("Subtração")){
            opcao = 2;
        }
        else if(spinner1.getSelectedItem().toString().equals("Multiplicação")){
            opcao = 3;
        }
        else if(spinner1.getSelectedItem().toString().equals("Divisão")){
            opcao = 4;
        }

        if(opcao == 1){
            Calculadora soma = new Calculadora();
            soma.setValor1(Double.parseDouble(edv1.getText().toString()));
            soma.setValor2(Double.parseDouble(edv2.getText().toString()));
            edresult.setText(String.format("%.3f",soma.Somar()));
        }

        else if(opcao == 2){
            Calculadora subtracao = new Calculadora();
            subtracao.setValor1(Double.parseDouble(edv1.getText().toString()));
            subtracao.setValor2(Double.parseDouble(edv2.getText().toString()));
            edresult.setText(String.format("%.3f",subtracao.Subtracao()));
        }
        else if(opcao == 3){
            Calculadora multiplicar = new Calculadora();
            multiplicar.setValor1(Double.parseDouble(edv1.getText().toString()));
            multiplicar.setValor2(Double.parseDouble(edv2.getText().toString()));
            edresult.setText(String.format("%.3f",multiplicar.Multiplicacao()));
        }
        else if(opcao == 4){
            Calculadora dividir = new Calculadora();
            dividir.setValor1(Double.parseDouble(edv1.getText().toString()));
            dividir.setValor2(Double.parseDouble(edv2.getText().toString()));
            edresult.setText(String.format("%.3f",dividir.Divisao()));
        }
    }

}
