package com.example.appemergncia;

public class Paciente {
    private String nome;
    private float peso;
    private int idade;
    private String sexo;
    private String tipoSanguineo;
    private String podeDoar;
    private String podeReceber;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPeso(){
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTipoSanguineo() {
        return tipoSanguineo;
    }

    public void setTipoSanguineo(String tipoSanguineo) {
        this.tipoSanguineo = tipoSanguineo;
    }

    public String getPodeDoar() {
        return podeDoar;
    }

    public void setPodeDoar(String podeDoar) {
        this.podeDoar = podeDoar;
    }

    public String getPodeReceber() {
        return podeReceber;
    }

    public void setPodeReceber(String podeReceber) {
        this.podeReceber = podeReceber;
    }

    public Paciente(){
        nome = "Nome...";
        sexo = "Sexo...";
        tipoSanguineo = "Tipo Sanguíneo...";
        peso = (float) 0.0;
        idade = 0;
        podeDoar = "Pode doar...";
        podeReceber = "Pode receber... ";
    }

    public String textoCadastro(){
        String item = "";
        item += getNome();
        item +="  ";
        item += getSexo();
        item +="  ";
        item += getTipoSanguineo();
        item +="  ";
        item += getPeso();
        item +="Kg  ";
        item += getIdade();
        item +=" anos\nDoador: ";
        item += getPodeDoar();
        item +="\nReceptor: ";
        item += getPodeReceber();
        return item;
    }
}
