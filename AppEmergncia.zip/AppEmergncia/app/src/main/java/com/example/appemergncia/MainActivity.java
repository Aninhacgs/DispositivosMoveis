package com.example.appemergncia;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    EditText ednome, edidade, edpeso;
    RadioButton rbFeminino,rbMasculino;
    ListView lista1;
    Spinner spinner;
    //Tamnho de elementos da lista
    public static final int TAM = 15;
    //Vetor para armazenar itens que estão na lista
    public String[] paciente = new String[TAM];
    //Vetor de objetos paciente
    public Paciente vetPaciente[] = new Paciente[TAM];
    //Para manter o valor do índice que está sendo alterado
    public int indiceItem = 0;
    //ArrayAdapter para relacionar os elemetos do vetor com a lista
    ArrayAdapter adapter;

    SharedPreferences prefis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ednome = (EditText)findViewById(R.id.editTextNome);
        edidade = (EditText)findViewById(R.id.editTextIdade);
        edpeso = (EditText)findViewById(R.id.editTextPeso);
        lista1 = (ListView)findViewById(R.id.ListViewCadastro);
        rbMasculino = (RadioButton)findViewById(R.id.radioButtonMasculino);
        rbFeminino = (RadioButton)findViewById(R.id.radioButtonFeminino);
        spinner = (Spinner)findViewById(R.id.spinner);

        //Definição do arquivo de preferências com o nome do arquivo e o modo do compartilhamento de dados privado
        prefis = getSharedPreferences("dadosUsuario",MODE_PRIVATE);

        //Método para preencher a tela com dados do arquivo de preferências ou com valores padrão
        iniciarUsuario();

        inicializarVetor();
        atualizarLista();
        lista1.setOnItemClickListener(this);
    }

    private void inicializarVetor(){
        for(int i=0;i<vetPaciente.length;i++){
            vetPaciente[i] = new Paciente();
        }
    }

    private void atualizarLista(){
        for(int i=0;i<paciente.length;i++){
            paciente[i] = vetPaciente[i].textoCadastro();
        }

        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,paciente);
        lista1.setAdapter(adapter);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        indiceItem = position;
        ednome.setText(vetPaciente[indiceItem].getNome());
        edidade.setText(String.valueOf(vetPaciente[indiceItem].getIdade()));
        edpeso.setText(String.valueOf(vetPaciente[indiceItem].getPeso()));
        Toast.makeText(getApplicationContext(),"Você selecionou o item do índice: "+ position,Toast.LENGTH_SHORT).show();

    }

    protected void iniciarUsuario(){
        if(prefis.contains("nome")){
            ednome.setText(prefis.getString("nome",""));
        }else{
            ednome.setText("Digite seu nome!");
        }

        if(prefis.contains("idade")){
            edidade.setText(String.valueOf(prefis.getInt("idade",0)));
        }else{
            edidade.setText("0");
        }

        if(prefis.contains("peso")){
            edpeso.setText(String.valueOf(prefis.getFloat("Peso",0.0f)));
        }else{
            edpeso.setText("0.0");
        }

        if(prefis.contains("sexo")){
            if(prefis.getBoolean("sexo",true)){
                rbFeminino.setChecked(true);
            }else{
                rbMasculino.setChecked(true);
            }
        }else{
            rbFeminino.setChecked(true);
        }
    }


    public void cadastrar(View v){
        SharedPreferences.Editor prefUsuario = prefis.edit();
        prefUsuario.putString("nome",ednome.getText().toString());
        prefUsuario.putInt("idade",Integer.parseInt(edidade.getText().toString()));
        prefUsuario.putFloat("peso",Float.parseFloat(edpeso.getText().toString()));
        vetPaciente[indiceItem].setNome(ednome.getText().toString());
        vetPaciente[indiceItem].setIdade(Integer.parseInt(edidade.getText().toString()));
        vetPaciente[indiceItem].setPeso(Float.parseFloat(edpeso.getText().toString()));

        //Definição do tipo sanguíneo
        if(spinner.getSelectedItem().toString().equals("A+")){
            vetPaciente[indiceItem].setTipoSanguineo("A+");
        }
        else if(spinner.getSelectedItem().toString().equals("A-")){
            vetPaciente[indiceItem].setTipoSanguineo("A-");
        }
        else if(spinner.getSelectedItem().toString().equals("B+")){
            vetPaciente[indiceItem].setTipoSanguineo("B+");
        }
        else if(spinner.getSelectedItem().toString().equals("B-")){
            vetPaciente[indiceItem].setTipoSanguineo("B-");
        }
        else if(spinner.getSelectedItem().toString().equals("AB+")){
            vetPaciente[indiceItem].setTipoSanguineo("AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("AB-")){
            vetPaciente[indiceItem].setTipoSanguineo("AB-");
        }
        else if(spinner.getSelectedItem().toString().equals("O+")){
            vetPaciente[indiceItem].setTipoSanguineo("O+");
        }
        else if(spinner.getSelectedItem().toString().equals("O-")){
            vetPaciente[indiceItem].setTipoSanguineo("O-");
        }

        //Definição do sexo
        if(rbFeminino.isChecked()){
            vetPaciente[indiceItem].setSexo("Feminino");
        }
        else if(rbMasculino.isChecked()){
            vetPaciente[indiceItem].setSexo("Masculino");
        }

        //Definição de doador
        if(spinner.getSelectedItem().toString().equals("A+")){
            vetPaciente[indiceItem].setPodeDoar("A+ e AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("A-")){
            vetPaciente[indiceItem].setPodeDoar("A-, A+, AB+ e AB-");
        }
        else if(spinner.getSelectedItem().toString().equals("B+")){
            vetPaciente[indiceItem].setPodeDoar("B+ e AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("B-")){
            vetPaciente[indiceItem].setPodeDoar("B-, B+, AB+ e AB-");
        }
        else if(spinner.getSelectedItem().toString().equals("AB+")){
            vetPaciente[indiceItem].setPodeDoar("AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("AB-")){
            vetPaciente[indiceItem].setPodeDoar("AB- e AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("O+")){
            vetPaciente[indiceItem].setPodeDoar("O+, A+, B+ e AB+");
        }
        else if(spinner.getSelectedItem().toString().equals("O-")){
            vetPaciente[indiceItem].setPodeDoar("Todos");
        }

        //Definição de Receptor
        if(spinner.getSelectedItem().toString().equals("A+")){
            vetPaciente[indiceItem].setPodeReceber("A+, A-, O+ e O-");
        }
        else if(spinner.getSelectedItem().toString().equals("A-")){
            vetPaciente[indiceItem].setPodeReceber("A- e O-");
        }
        else if(spinner.getSelectedItem().toString().equals("B+")){
            vetPaciente[indiceItem].setPodeReceber("B+, B-, O+ e O-");
        }
        else if(spinner.getSelectedItem().toString().equals("B-")){
            vetPaciente[indiceItem].setPodeReceber("B- e O-");
        }
        else if(spinner.getSelectedItem().toString().equals("AB+")){
            vetPaciente[indiceItem].setPodeReceber("Todos");
        }
        else if(spinner.getSelectedItem().toString().equals("AB-")){
            vetPaciente[indiceItem].setPodeReceber("A-, B-, O- e AB-");
        }
        else if(spinner.getSelectedItem().toString().equals("O+")){
            vetPaciente[indiceItem].setPodeReceber("O+ e O-");
        }
        else if(spinner.getSelectedItem().toString().equals("O-")){
            vetPaciente[indiceItem].setPodeReceber("O-");
        }

        //Confirmação da alteração
        prefUsuario.apply();

        //Mensagem de aviso ao usuário
        Toast.makeText(getApplicationContext(),"Suas preferências foram salvas\nAguarde alguns instantes para sair.",Toast.LENGTH_LONG).show();

        atualizarLista();
    }
}
